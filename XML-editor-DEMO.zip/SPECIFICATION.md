# Specifikation — XSD-styrd XML-editor

Version: 1.0 (nulägesbeskrivning, 2026-08-02)
Omfattning: allt som är byggt i projektet till och med idag. Ingen backend, ingen inloggning, ingen persistens — allt körs i webbläsaren.

---

## 1. Syfte

Applikationen är en visuell editor för XML-dokument som styrs av ett XSD-schema. Användaren laddar in ett schema, bygger upp XML-strukturen i en trädvy, redigerar attribut med schemastyrda kontroller (skjutreglage, dropplistor, checkboxar) och ser hela tiden motsvarande XML-källkod med syntaxfärgning. Källkoden är redigerbar och synkas tillbaka till trädet.

Målgruppen är den som skriver strukturerad XML mot ett känt schema (t.ex. audio-/synth-konfiguration — se de domänanpassade numeriska intervallen i avsnitt 6.3).

## 2. Teknisk grund

- React 18 + TypeScript 5, Vite 5, Tailwind CSS v3, shadcn/ui (Popover används i trädet), lucide-react-ikoner.
- Routing via react-router-dom: `/` = editorn (`src/pages/Index.tsx`), `*` = 404-sida.
- Ingen server, inga externa API:er utom hämtning av schema via URL (`fetch`).
- Tester: Vitest är konfigurerat (`src/test/`), i nuläget finns endast ett exempeltest.
- Semantiska designtokens i `src/index.css` / `tailwind.config.ts`, inklusive egna tokens för träd (`tree-node`, `tree-node-selected`, `tree-node-border`, `tree-node-hover`) och kodeditor (`editor-gutter`, `syntax-tag`, `syntax-attr`, `syntax-text` m.fl.).

### Filstruktur (kärnan)

```text
src/
  pages/Index.tsx            Applikationens tillstånd och layout
  components/
    SchemaInput.tsx          Toppfält: ladda XSD via fil eller URL
    XmlTreeView.tsx          Trädvy, drag & drop, filsläpp, byt elementnamn
    NodeInspector.tsx        Inspektor för valt element (attribut, text, namn)
    XmlCodeEditor.tsx        XML-källkod med egen syntaxfärgning
  lib/
    xml-types.ts             Typer: XmlNode, SchemaElement, SchemaAttribute, ParsedSchema
    xml-utils.ts             Parsning, serialisering och immutabla trädoperationer
    schema-utils.ts          XSD-parser -> ParsedSchema
public/scheme_1.23.xsd       Exempelschema
```

## 3. Datamodell

`XmlNode` (`src/lib/xml-types.ts`):

| Fält | Typ | Beskrivning |
| --- | --- | --- |
| `id` | `string` | Löpnummer `node_N`, unikt per session |
| `tagName` | `string` | Elementnamn |
| `attributes` | `Record<string,string>` | Attribut i insättningsordning |
| `children` | `XmlNode[]` | Barnelement i dokumentordning |
| `textContent` | `string` | Sammanslagen, trimmad textnod |
| `parent` | `string \| null` | Förälderns id, `null` för roten |

`ParsedSchema` består av `rootElements: string[]` och `elements: Record<string, SchemaElement>`, där varje `SchemaElement` har `allowedChildren: string[]` och `allowedAttributes: SchemaAttribute[]`. Ett attribut beskrivs av namn, typ (`string | number | boolean | enum`), `required`, `enumValues`, `minValue`/`maxValue`, `defaultValue` och `pattern`.

## 4. Layout

Helskärmslayout i tre zoner:

```text
+---------------------------------------------------------------+
| Schema: [Upload XSD] eller [Schema-URL ...] [Load]   (status) |
+-----------------------------+---------------------------------+
| XML STRUCTURE (trädvy)      | XML SOURCE (kod, syntaxfärgad)  |
| ...                         | ...                             |
+-----------------------------+                                 |
| INSPECTOR (valt element)    |                                 |
+-----------------------------+---------------------------------+
```

Vänster halva: trädvy (scrollbar) med inspektorn fäst i underkanten, max 40 % av fönsterhöjden. Höger halva: källkodseditorn.

## 5. Schemahantering

### 5.1 Inläsning (`SchemaInput`)
- Filuppladdning av `.xsd`/`.xml`, läses lokalt med `FileReader`.
- Inläsning från URL via `fetch`; filnamnet härleds ur URL:en.
- Vid lyckad parsning visas en chip med filnamnet och ett kryss som nollställer schemat.
- Felmeddelanden vid misslyckad parsning respektive misslyckad hämtning.
- Utan schema visas "No schema — manual mode": allt är då fritt redigerbart utan förslag.

### 5.2 XSD-parsern (`parseXsdSchema`)
Parsern använder `DOMParser` och arbetar prefixoberoende via `localName`, dvs. `xs:`, `xsd:` eller inget prefix fungerar lika bra. Den:

1. Indexerar globala deklarationer: `element`, `complexType`, `group`, `attributeGroup`.
2. Sätter alla globala elementdeklarationer som möjliga rotelement.
3. Löser upp varje elements typ: namngiven `type`-referens eller inline `complexType`.
4. Samlar tillåtna barn rekursivt genom `sequence`, `choice`, `all`, `group ref`, inline-grupper samt `complexContent`/`simpleContent` med `extension`/`restriction` (basetypen inkluderas). Både `ref` och `name` på `element` stöds; barn i ordning, dubletter filtreras.
5. Samlar attribut rekursivt inklusive `attributeGroup ref` och innehållsmodeller; första förekomsten av ett namn vinner.
6. Tolkar attributrestriktioner: `use="required"`, `default`, numeriska XSD-typer (`integer`, `int`, `decimal`, `float`, `double`), `boolean`, `enumeration` -> enum, `pattern` -> regex, `minInclusive`/`maxInclusive` -> intervall.
7. Skyddar mot oändlig rekursion genom att reservera elementplatsen innan bearbetning; returnerar `null` om XML:en inte kan parsas.

## 6. Funktioner

### 6.1 Trädvy (`XmlTreeView`)
- Skapa rot: dropplista med schemats rotelement (alfabetiskt) plus "Other…", eller fritextfält när schema saknas.
- Rekursiv rendering med indrag 20 px per nivå och kopplingslinjer; noder kan fällas in/ut när de har barn.
- Val av nod markeras med ram och accentbakgrund och styr inspektorn.
- Inline-förhandsvisning av attribut, prioritetsordnad: `id`, `class`, därefter schemats ordning, sedan övriga. Textinnehåll visas trunkerat i citattecken.
- Klick på elementnamnet öppnar en popover för att byta namn; alternativen är förälderns tillåtna barn (eller schemats rotelement för roten). Utan alternativ visas namnet som ren text.
- Åtgärdsknappar per nod: lägg till barn, duplicera, flytta upp, flytta ner, radera (ej på roten). Ett "Add element"-fält visas även efter sista barnet. När ett element bara tillåter ett barn används det namnet automatiskt, annars `element`.
- Drag & drop-omflyttning: rotnoden kan inte dras. Träffzoner i noden ger `before` (övre 25 %), `inside` (mitten) och `after` (nedre 25 %) med indikatorlinje respektive ram. Index justeras när noden flyttas inom samma förälder, och en nod kan aldrig släppas i sig själv eller i en egen efterkommande.

### 6.2 Filsläpp till attribut
Filer som dras från operativsystemet till en nod fyller automatiskt nodens `src`- eller `source`-attribut med filnamnet, förutsatt att schemat tillåter attributet (skiftlägesokänslig matchning, schemats stavning behålls). Giltiga mål får accentram och en etikett med attributnamnet och en ikon; ogiltiga mål sätter `dropEffect = "none"`. Filsläpp och nodflytt skiljs åt genom `dataTransfer.types`. Endast filnamnet lagras — filinnehållet läses inte.

### 6.3 Inspektor (`NodeInspector`)
Panelen visar valt element och ger:
- Fritextfält för elementnamn och för textinnehåll.
- Attributlista med schemastyrd kontroll per typ:
  - `boolean`: checkbox.
  - `enum`: dropplista med tillåtna värden, med möjlighet att växla till fritext.
  - `number`: skjutreglage kombinerat med sifferfält, med `min`/`max`/`step` från schemat.
  - `string`: textfält; om schemat har `pattern` valideras värdet mot `^pattern$` och ramen blir grön eller röd.
- Ta bort attribut, samt lägg till attribut via dropplista över oanvända tillåtna attribut (alfabetiskt) eller "Other…" för fritt namn. Nya värden förifylls från `default`, `false` för boolean, `minValue` för tal och första enum-värdet.
- Smarta numeriska standardintervall när schemat saknar min/max, baserat på attributnamnet: frequency 0–20000, gain/volume/level/amplitude 0–1, pan/balance −1–1, q/resonance 0–100, delay/time/duration 0–10, rate/speed 0–10, detune ±1200, octave ±4, semitone ±12, cent ±100, angle/phase 0–360, percent/mix/wet/dry/feedback 0–100, pitch ±24, bpm/tempo 20–300, channel 0–16, velocity och note 0–127. Annars 0–100. Steglängden anpassas efter intervallets storlek (1 / 0,1 / 0,01).
- Utan valt element visas "Select a node to inspect".

### 6.4 Källkodseditor (`XmlCodeEditor`)
Egen editor med radnummer och radvis tokenisering av XML: kommentarer, processinstruktioner (`<?xml … ?>`), öppnande/stängande/självstängande taggar, attributnamn, citerade attributvärden och text. Tokens färgas med syntaxtokens från designsystemet. Texten är redigerbar och varje ändring försöker parsas.

### 6.5 Tvåvägssynkronisering
`Index.tsx` håller sanningen: `root`, `schema`, `selectedNodeId` och `codeValue`.
- Träd -> kod: varje trädoperation serialiserar om hela dokumentet med `<?xml version="1.0" encoding="UTF-8"?>` som första rad, två blankstegs indrag, självstängande taggar för tomma element och XML-escapning av `& < > " '`.
- Kod -> träd: inmatad kod parsas med `DOMParser`; endast giltig XML uppdaterar trädet, så användaren kan skriva vidare i ett tillfälligt ogiltigt läge utan att trädet raderas.
- Två `useRef`-flaggor förhindrar att synkroniseringen loopar.

### 6.6 Trädoperationer (`xml-utils.ts`)
Alla operationer är rena och immutabla: `parseXmlString`, `serializeXmlNode`, `generateFullXml`, `createXmlNode`, `findNodeById`, `cloneNode` (djupkopia med nya id:n), `updateParentRefs`, `removeNode`, `insertChild`, `moveChild`, `updateNodeAttributes`, `updateNodeTagName`, `updateNodeTextContent` och `reparentNode` (med skydd mot cykler och mot flytt av roten). Duplicering placerar kopian direkt efter originalet och markerar den.

## 7. Avgränsningar i nuläget

- Ingen persistens: allt tillstånd försvinner vid omladdning. Ingen export- eller nedladdningsknapp; XML kopieras manuellt ur källkodsrutan.
- Ingen fullständig XSD-validering: `minOccurs`/`maxOccurs` finns i typerna men används inte, ordningskrav i `sequence` upprätthålls inte, och ogiltig struktur blockeras inte — schemat används som förslag och kontrollstyrning.
- Namnrymder, `import`/`include`, `substitutionGroup`, abstrakta typer och `xsi:type` hanteras inte.
- Ingen ångra/gör om, inget flerval, ingen sökning eller filtrering i trädet.
- Endast första filen används vid filsläpp och bara filnamnet lagras.
- Layouten är byggd för skrivbordsbredd (fasta halvor) och är inte mobiloptimerad.
- Metadata i `index.html` är fortfarande Lovables standardvärden.
- Testtäckningen är i praktiken tom.

## 8. Naturliga nästa steg

1. Sätt titel, beskrivning och delningsmetadata i `index.html`.
2. Export/nedladdning av XML samt import av befintlig XML-fil.
3. Ångra/gör om över trädtillståndet.
4. Schemavalidering med felmarkeringar i trädet (obligatoriska attribut, kardinalitet, ordning).
5. Persistens av dokument och senast använt schema.
6. Enhetstester för `xml-utils` och `schema-utils`.
