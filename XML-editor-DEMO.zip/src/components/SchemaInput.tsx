import React, { useState } from "react";
import { Upload, Link, FileText, X } from "lucide-react";
import { parseXsdSchema } from "@/lib/schema-utils";
import { ParsedSchema } from "@/lib/xml-types";

interface SchemaInputProps {
  onSchemaLoaded: (schema: ParsedSchema | null) => void;
  hasSchema: boolean;
}

const SchemaInput: React.FC<SchemaInputProps> = ({ onSchemaLoaded, hasSchema }) => {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [fileName, setFileName] = useState("");

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError("");
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      const schema = parseXsdSchema(text);
      if (schema) {
        onSchemaLoaded(schema);
      } else {
        setError("Failed to parse schema file");
        onSchemaLoaded(null);
      }
    };
    reader.readAsText(file);
  };

  const handleUrlLoad = async () => {
    if (!url.trim()) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch(url);
      const text = await res.text();
      const schema = parseXsdSchema(text);
      if (schema) {
        setFileName(url.split("/").pop() || "schema.xsd");
        onSchemaLoaded(schema);
      } else {
        setError("Failed to parse schema from URL");
      }
    } catch {
      setError("Failed to fetch schema from URL");
    }
    setLoading(false);
  };

  const handleClear = () => {
    setFileName("");
    setUrl("");
    setError("");
    onSchemaLoaded(null);
  };

  return (
    <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-card">
      <FileText className="w-4 h-4 text-muted-foreground shrink-0" />
      <span className="text-xs font-medium text-muted-foreground shrink-0">Schema:</span>

      {hasSchema && fileName ? (
        <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-primary/10 text-primary text-xs font-medium">
          {fileName}
          <button onClick={handleClear} className="ml-1 hover:text-destructive">
            <X className="w-3 h-3" />
          </button>
        </div>
      ) : (
        <>
          <label className="flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-secondary hover:bg-secondary/80 cursor-pointer transition-colors">
            <Upload className="w-3 h-3" />
            Upload XSD
            <input type="file" accept=".xsd,.xml" onChange={handleFileUpload} className="hidden" />
          </label>

          <span className="text-xs text-muted-foreground">or</span>

          <div className="flex items-center gap-1 flex-1 max-w-xs">
            <input
              type="text"
              placeholder="Schema URL..."
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleUrlLoad()}
              className="flex-1 px-2 py-1 text-xs rounded border border-input bg-background focus:outline-none focus:ring-1 focus:ring-ring"
            />
            <button
              onClick={handleUrlLoad}
              disabled={loading || !url.trim()}
              className="flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors"
            >
              <Link className="w-3 h-3" />
              {loading ? "..." : "Load"}
            </button>
          </div>
        </>
      )}

      {error && <span className="text-xs text-destructive">{error}</span>}
      {!hasSchema && (
        <span className="text-xs text-muted-foreground italic ml-auto">No schema — manual mode</span>
      )}
    </div>
  );
};

export default SchemaInput;
