import React, { useRef, useEffect, useState, useCallback } from "react";

interface XmlCodeEditorProps {
  value: string;
  onChange: (value: string) => void;
}

// Tokenize XML for syntax highlighting
function tokenizeXml(code: string): { type: string; text: string }[][] {
  const lines = code.split("\n");
  return lines.map((line) => {
    const tokens: { type: string; text: string }[] = [];
    let i = 0;

    while (i < line.length) {
      // Comment
      if (line.startsWith("<!--", i)) {
        const end = line.indexOf("-->", i);
        if (end !== -1) {
          tokens.push({ type: "comment", text: line.slice(i, end + 3) });
          i = end + 3;
        } else {
          tokens.push({ type: "comment", text: line.slice(i) });
          i = line.length;
        }
      }
      // Processing instruction
      else if (line.startsWith("<?", i)) {
        const end = line.indexOf("?>", i);
        if (end !== -1) {
          tokens.push({ type: "comment", text: line.slice(i, end + 2) });
          i = end + 2;
        } else {
          tokens.push({ type: "comment", text: line.slice(i) });
          i = line.length;
        }
      }
      // Closing tag
      else if (line.startsWith("</", i)) {
        tokens.push({ type: "bracket", text: "</" });
        i += 2;
        const tagEnd = line.indexOf(">", i);
        if (tagEnd !== -1) {
          tokens.push({ type: "tag", text: line.slice(i, tagEnd) });
          tokens.push({ type: "bracket", text: ">" });
          i = tagEnd + 1;
        }
      }
      // Opening tag or self-closing
      else if (line[i] === "<" && line[i + 1] !== "/") {
        tokens.push({ type: "bracket", text: "<" });
        i += 1;
        // Tag name
        let tagName = "";
        while (i < line.length && !/[\s/>]/.test(line[i])) {
          tagName += line[i];
          i++;
        }
        if (tagName) tokens.push({ type: "tag", text: tagName });

        // Attributes
        while (i < line.length && line[i] !== ">" && !(line[i] === "/" && line[i + 1] === ">")) {
          if (/\s/.test(line[i])) {
            tokens.push({ type: "text", text: line[i] });
            i++;
            continue;
          }
          // Attribute name
          let attrName = "";
          while (i < line.length && line[i] !== "=" && !/[\s/>]/.test(line[i])) {
            attrName += line[i];
            i++;
          }
          if (attrName) tokens.push({ type: "attr-name", text: attrName });

          if (line[i] === "=") {
            tokens.push({ type: "bracket", text: "=" });
            i++;
            // Attribute value
            if (line[i] === '"' || line[i] === "'") {
              const quote = line[i];
              let val = quote;
              i++;
              while (i < line.length && line[i] !== quote) {
                val += line[i];
                i++;
              }
              if (i < line.length) {
                val += line[i];
                i++;
              }
              tokens.push({ type: "attr-value", text: val });
            }
          }
        }

        if (line[i] === "/" && line[i + 1] === ">") {
          tokens.push({ type: "bracket", text: "/>" });
          i += 2;
        } else if (line[i] === ">") {
          tokens.push({ type: "bracket", text: ">" });
          i += 1;
        }
      }
      // Plain text
      else {
        let text = "";
        while (i < line.length && line[i] !== "<") {
          text += line[i];
          i++;
        }
        if (text) tokens.push({ type: "text", text });
      }
    }

    return tokens;
  });
}

const colorMap: Record<string, string> = {
  tag: "text-syntax-tag",
  "attr-name": "text-syntax-attr-name",
  "attr-value": "text-syntax-attr-value",
  bracket: "text-syntax-bracket",
  text: "text-syntax-text",
  comment: "text-syntax-comment",
};

const XmlCodeEditor: React.FC<XmlCodeEditorProps> = ({ value, onChange }) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const highlightRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const lines = value.split("\n");
  const tokenizedLines = tokenizeXml(value);

  const syncScroll = useCallback(() => {
    if (textareaRef.current && highlightRef.current) {
      highlightRef.current.scrollTop = textareaRef.current.scrollTop;
      highlightRef.current.scrollLeft = textareaRef.current.scrollLeft;
      setScrollTop(textareaRef.current.scrollTop);
      setScrollLeft(textareaRef.current.scrollLeft);
    }
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Tab") {
      e.preventDefault();
      const ta = textareaRef.current!;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const newValue = value.substring(0, start) + "  " + value.substring(end);
      onChange(newValue);
      requestAnimationFrame(() => {
        ta.selectionStart = ta.selectionEnd = start + 2;
      });
    }
  };

  const gutterWidth = Math.max(40, String(lines.length).length * 10 + 20);

  return (
    <div className="relative flex h-full bg-editor-bg font-mono text-sm overflow-hidden" ref={containerRef}>
      {/* Line numbers */}
      <div
        className="shrink-0 bg-editor-gutter text-editor-line-number text-right select-none py-3 leading-6 overflow-hidden"
        style={{ width: gutterWidth, transform: `translateY(-${scrollTop}px)` }}
      >
        {lines.map((_, i) => (
          <div key={i} className="h-6 pr-3">
            {i + 1}
          </div>
        ))}
      </div>

      {/* Highlighted code (behind textarea) */}
      <div
        ref={highlightRef}
        className="absolute top-0 bottom-0 right-0 py-3 pl-3 leading-6 pointer-events-none overflow-hidden whitespace-pre"
        style={{
          left: `${gutterWidth}px`,
          transform: `translate(-${scrollLeft}px, -${scrollTop}px)`,
        }}
        aria-hidden="true"
      >
        {tokenizedLines.map((lineTokens, lineIdx) => (
          <div key={lineIdx} className="h-6">
            {lineTokens.map((token, tokenIdx) => (
              <span key={tokenIdx} className={colorMap[token.type] || "text-syntax-text"}>
                {token.text}
              </span>
            ))}
            {lineTokens.length === 0 && "\u00A0"}
          </div>
        ))}
      </div>

      {/* Editable textarea (transparent, on top) */}
      <textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onScroll={syncScroll}
        onKeyDown={handleKeyDown}
        spellCheck={false}
        className="flex-1 bg-transparent text-transparent caret-editor-cursor py-3 pl-3 leading-6 resize-none outline-none xml-code-editor whitespace-pre overflow-auto selection:bg-editor-selection"
        style={{ caretColor: "hsl(var(--editor-cursor))" }}
      />
    </div>
  );
};

export default XmlCodeEditor;
