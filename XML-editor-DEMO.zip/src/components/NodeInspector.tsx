import React, { useState, useMemo } from "react";
import { Settings, Plus, Trash2 } from "lucide-react";
import { XmlNode, ParsedSchema, SchemaAttribute } from "@/lib/xml-types";

interface NodeInspectorProps {
  node: XmlNode | null;
  schema: ParsedSchema | null;
  onUpdateAttributes: (nodeId: string, attributes: Record<string, string>) => void;
  onUpdateTagName: (nodeId: string, tagName: string) => void;
  onUpdateTextContent: (nodeId: string, text: string) => void;
}

// Test a value against a regex pattern, returns null if no pattern
function testPattern(pattern: string | undefined, value: string): boolean | null {
  if (!pattern) return null;
  try {
    const re = new RegExp(`^${pattern}$`);
    return re.test(value);
  } catch {
    return null;
  }
}

// Smart range defaults for numeric attributes without schema-specified min/max
function getSmartRange(attrName: string, schemaMin?: number, schemaMax?: number): { min: number; max: number; step: number } {
  const hasMin = schemaMin !== undefined && schemaMin !== null;
  const hasMax = schemaMax !== undefined && schemaMax !== null;
  if (hasMin && hasMax) {
    const range = schemaMax! - schemaMin!;
    const step = range > 100 ? 1 : range > 10 ? 0.1 : 0.01;
    return { min: schemaMin!, max: schemaMax!, step };
  }

  const name = attrName.toLowerCase();
  if (name.includes("frequency") || name === "freq") return { min: 0, max: 20000, step: 1 };
  if (name.includes("gain") || name === "volume" || name === "level" || name === "amp" || name === "amplitude") return { min: 0, max: 1, step: 0.01 };
  if (name === "pan" || name === "balance") return { min: -1, max: 1, step: 0.01 };
  if (name === "q" || name === "quality" || name.includes("resonance")) return { min: 0, max: 100, step: 0.1 };
  if (name.includes("delay") || name.includes("time") || name.includes("duration")) return { min: 0, max: 10, step: 0.01 };
  if (name.includes("rate") || name.includes("speed")) return { min: 0, max: 10, step: 0.1 };
  if (name.includes("detune")) return { min: -1200, max: 1200, step: 1 };
  if (name.includes("octave")) return { min: -4, max: 4, step: 1 };
  if (name.includes("semitone")) return { min: -12, max: 12, step: 1 };
  if (name.includes("cent")) return { min: -100, max: 100, step: 1 };
  if (name.includes("angle") || name.includes("phase")) return { min: 0, max: 360, step: 1 };
  if (name.includes("percent") || name.includes("mix") || name === "wet" || name === "dry" || name === "feedback") return { min: 0, max: 100, step: 1 };
  if (name.includes("pitch")) return { min: -24, max: 24, step: 1 };
  if (name.includes("bpm") || name.includes("tempo")) return { min: 20, max: 300, step: 1 };
  if (name.includes("channel")) return { min: 0, max: 16, step: 1 };
  if (name.includes("velocity")) return { min: 0, max: 127, step: 1 };
  if (name.includes("note")) return { min: 0, max: 127, step: 1 };

  // Apply partial schema values
  const min = hasMin ? schemaMin! : 0;
  const max = hasMax ? schemaMax! : 100;
  const range = max - min;
  const step = range > 100 ? 1 : range > 10 ? 0.1 : 0.01;
  return { min, max, step };
}

const NodeInspector: React.FC<NodeInspectorProps> = ({
  node,
  schema,
  onUpdateAttributes,
  onUpdateTagName,
  onUpdateTextContent,
}) => {
  const [newAttrName, setNewAttrName] = useState("");
  const [newAttrValue, setNewAttrValue] = useState("");
  const [showCustomAttrName, setShowCustomAttrName] = useState(false);

  if (!node) {
    return (
      <div className="flex items-center justify-center text-muted-foreground text-sm p-4 border-t border-border shrink-0">
        Select a node to inspect
      </div>
    );
  }

  const schemaElement = schema?.elements[node.tagName];
  const allowedAttributes = schemaElement?.allowedAttributes || [];
  const allowedAttrNames = allowedAttributes.map((a) => a.name);

  const getAttrSchema = (name: string): SchemaAttribute | undefined =>
    allowedAttributes.find((a) => a.name === name);

  const handleAttrChange = (key: string, value: string) => {
    onUpdateAttributes(node.id, { ...node.attributes, [key]: value });
  };

  const handleRemoveAttr = (key: string) => {
    const newAttrs = { ...node.attributes };
    delete newAttrs[key];
    onUpdateAttributes(node.id, newAttrs);
  };

  const handleAddAttr = (name: string, value: string) => {
    if (!name.trim()) return;
    onUpdateAttributes(node.id, { ...node.attributes, [name]: value });
    setNewAttrName("");
    setNewAttrValue("");
    setShowCustomAttrName(false);
  };

  // Find unused allowed attributes, sorted alphabetically
  const unusedAllowedAttrs = allowedAttrNames
    .filter((name) => !(name in node.attributes))
    .sort((a, b) => a.localeCompare(b));

  return (
    <div className="border-t border-border bg-card overflow-auto shrink-0 max-h-[40vh]">
      <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-muted/50">
        <Settings className="w-4 h-4 text-primary" />
        <span className="text-xs font-semibold uppercase tracking-wide text-foreground">Inspector</span>
      </div>

      <div className="p-3 space-y-3">
        {/* Tag name */}
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">Element</label>
          <input
            type="text"
            value={node.tagName}
            onChange={(e) => onUpdateTagName(node.id, e.target.value)}
            className="w-full px-2 py-1.5 text-sm font-mono font-semibold rounded border border-input bg-background focus:outline-none focus:ring-1 focus:ring-ring"
          />
        </div>

        {/* Text content */}
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">Text Content</label>
          <input
            type="text"
            value={node.textContent}
            onChange={(e) => onUpdateTextContent(node.id, e.target.value)}
            placeholder="(empty)"
            className="w-full px-2 py-1.5 text-sm rounded border border-input bg-background focus:outline-none focus:ring-1 focus:ring-ring"
          />
        </div>

        {/* Attributes */}
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-2 block">Attributes</label>
          <div className="space-y-2">
            {Object.entries(node.attributes).map(([key, value]) => (
              <AttributeRow
                key={key}
                attrName={key}
                value={value}
                attrSchema={getAttrSchema(key)}
                onChange={(v) => handleAttrChange(key, v)}
                onRemove={() => handleRemoveAttr(key)}
              />
            ))}
          </div>

          {/* Add attribute */}
          <div className="flex items-center gap-2 mt-2 pt-2 border-t border-border">
            {unusedAllowedAttrs.length > 0 && !showCustomAttrName ? (
              <select
                value={newAttrName}
                onChange={(e) => {
                  const name = e.target.value;
                  if (name === "__custom__") {
                    setShowCustomAttrName(true);
                    setNewAttrName("");
                    return;
                  }
                  setShowCustomAttrName(false);
                  setNewAttrName(name);
                  const attrSchema = getAttrSchema(name);
                  if (attrSchema?.defaultValue) setNewAttrValue(attrSchema.defaultValue);
                  else if (attrSchema?.type === "boolean") setNewAttrValue("false");
                  else if (attrSchema?.type === "number") setNewAttrValue(String(attrSchema.minValue ?? 0));
                  else if (attrSchema?.enumValues?.[0]) setNewAttrValue(attrSchema.enumValues[0]);
                }}
                className="px-2 py-1 text-xs rounded border border-input bg-background focus:outline-none focus:ring-1 focus:ring-ring"
              >
                <option value="" disabled>Add attribute...</option>
                {unusedAllowedAttrs.map((name) => (
                  <option key={name} value={name}>{name}</option>
                ))}
                <option value="__custom__">Other...</option>
              </select>
            ) : null}
            {(showCustomAttrName || unusedAllowedAttrs.length === 0) && (
              <input
                type="text"
                placeholder="Attribute name"
                value={newAttrName}
                onChange={(e) => setNewAttrName(e.target.value)}
                className="w-24 px-2 py-1 text-xs rounded border border-input bg-background focus:outline-none focus:ring-1 focus:ring-ring font-mono"
                autoFocus
              />
            )}
            <input
              type="text"
              placeholder="Value"
              value={newAttrValue}
              onChange={(e) => setNewAttrValue(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddAttr(newAttrName, newAttrValue)}
              className="flex-1 px-2 py-1 text-xs rounded border border-input bg-background focus:outline-none focus:ring-1 focus:ring-ring font-mono"
            />
            <button
              onClick={() => handleAddAttr(newAttrName, newAttrValue)}
              disabled={!newAttrName.trim()}
              className="p-1 rounded bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
            {showCustomAttrName && (
              <button
                onClick={() => { setShowCustomAttrName(false); setNewAttrName(""); }}
                className="px-2 py-1 rounded text-xs text-muted-foreground hover:bg-secondary transition-colors"
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Attribute value row with schema-driven controls ---
const AttributeRow: React.FC<{
  attrName: string;
  value: string;
  attrSchema: SchemaAttribute | undefined;
  onChange: (value: string) => void;
  onRemove: () => void;
}> = ({ attrName, value, attrSchema, onChange, onRemove }) => {
  const [showCustomInput, setShowCustomInput] = useState(false);

  const patternValid = useMemo(
    () => testPattern(attrSchema?.pattern, value),
    [attrSchema?.pattern, value]
  );

  const patternBorderClass =
    patternValid === null ? "" : patternValid ? "border-green-500" : "border-destructive";

  const renderValueControl = () => {
    // Boolean
    if (attrSchema?.type === "boolean") {
      return (
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={value === "true"}
            onChange={(e) => onChange(e.target.checked ? "true" : "false")}
            className="w-4 h-4 rounded border-input accent-primary"
          />
          <span className="text-xs text-muted-foreground">{value === "true" ? "true" : "false"}</span>
        </label>
      );
    }

    // Enum (string with options) or number with enum values
    if (attrSchema?.enumValues && attrSchema.enumValues.length > 0) {
      const isNumeric = attrSchema.type === "number";
      const sorted = isNumeric
        ? [...attrSchema.enumValues].sort((a, b) => parseFloat(a) - parseFloat(b))
        : [...attrSchema.enumValues].sort((a, b) => a.localeCompare(b));
      const isOther = !sorted.includes(value) || showCustomInput;
      return (
        <div className="flex items-center gap-2 flex-1">
          <select
            value={isOther ? "__other__" : value}
            onChange={(e) => {
              if (e.target.value === "__other__") {
                setShowCustomInput(true);
                return;
              }
              setShowCustomInput(false);
              onChange(e.target.value);
            }}
            className="flex-1 px-2 py-1 text-xs rounded border border-input bg-background focus:outline-none focus:ring-1 focus:ring-ring"
          >
            {sorted.map((v) => (
              <option key={v} value={v}>{v}</option>
            ))}
            <option value="__other__">Custom...</option>
          </select>
          {isOther && (
            <input
              type={isNumeric ? "number" : "text"}
              value={value}
              onChange={(e) => onChange(e.target.value)}
              className={`w-24 px-1.5 py-0.5 text-xs rounded border bg-background focus:outline-none focus:ring-1 focus:ring-ring font-mono ${patternBorderClass || "border-input"}`}
              autoFocus
            />
          )}
          {patternValid === false && <span className="text-destructive text-[10px] shrink-0" title={`Pattern: ${attrSchema?.pattern}`}>✗</span>}
          {patternValid === true && <span className="text-green-500 text-[10px] shrink-0">✓</span>}
        </div>
      );
    }

    // Number with slider
    if (attrSchema?.type === "number") {
      const range = getSmartRange(attrName, attrSchema.minValue, attrSchema.maxValue);
      const numVal = parseFloat(value) || range.min;
      const isOutOfRange = numVal < range.min || numVal > range.max;
      return (
        <div className="flex items-center gap-2 flex-1">
          {!showCustomInput && (
            <input
              type="range"
              min={range.min}
              max={range.max}
              step={range.step}
              value={Math.min(Math.max(numVal, range.min), range.max)}
              onChange={(e) => onChange(e.target.value)}
              className="flex-1 accent-primary"
            />
          )}
          <input
            type="number"
            value={value}
            step={range.step}
            onChange={(e) => onChange(e.target.value)}
            className={`w-20 px-1.5 py-0.5 text-xs rounded border bg-background text-right focus:outline-none focus:ring-1 focus:ring-ring ${patternBorderClass || "border-input"}`}
          />
          <button
            onClick={() => setShowCustomInput(!showCustomInput)}
            className={`px-1.5 py-0.5 rounded text-[10px] transition-colors ${showCustomInput ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:bg-secondary/80"}`}
            title={showCustomInput ? "Show slider" : "Custom value (outside range)"}
          >
            {showCustomInput ? "Slider" : "Custom"}
          </button>
        </div>
      );
    }

    // String (default) with pattern validation
    return (
      <div className="flex items-center gap-1 flex-1">
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className={`flex-1 px-2 py-1 text-xs rounded border bg-background focus:outline-none focus:ring-1 focus:ring-ring font-mono ${patternBorderClass || "border-input"}`}
        />
        {patternValid === false && (
          <span className="text-destructive text-[10px] shrink-0" title={`Pattern: ${attrSchema?.pattern}`}>✗</span>
        )}
        {patternValid === true && (
          <span className="text-green-500 text-[10px] shrink-0">✓</span>
        )}
      </div>
    );
  };

  return (
    <div className="flex items-center gap-2">
      <span className="text-xs font-mono font-medium text-syntax-attr-name shrink-0 min-w-[80px]">
        {attrName}
      </span>
      {renderValueControl()}
      <button
        onClick={onRemove}
        className="p-0.5 rounded hover:bg-destructive/20 text-destructive shrink-0"
      >
        <Trash2 className="w-3 h-3" />
      </button>
    </div>
  );
};

export default NodeInspector;
