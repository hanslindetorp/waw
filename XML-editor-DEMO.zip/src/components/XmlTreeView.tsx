import React, { useState, useCallback, useRef } from "react";
import { ChevronRight, ChevronDown, Plus, Trash2, ArrowUp, ArrowDown, Copy, GripVertical, FileDown } from "lucide-react";
import { XmlNode, ParsedSchema } from "@/lib/xml-types";
import { createXmlNode, findNodeById } from "@/lib/xml-utils";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";

interface XmlTreeViewProps {
  root: XmlNode | null;
  selectedNodeId: string | null;
  schema: ParsedSchema | null;
  onSelectNode: (id: string) => void;
  onAddChild: (parentId: string, tagName: string) => void;
  onRemoveNode: (id: string) => void;
  onMoveNode: (id: string, direction: "up" | "down") => void;
  onCopyNode: (id: string) => void;
  onSetRoot: (node: XmlNode) => void;
  onReparentNode?: (nodeId: string, newParentId: string, index?: number) => void;
  onUpdateAttributes?: (nodeId: string, attributes: Record<string, string>) => void;
  onUpdateTagName?: (nodeId: string, tagName: string) => void;
}

// DnD context
interface DragState {
  draggedNodeId: string | null;
  dropTargetId: string | null;
  dropPosition: "before" | "inside" | "after" | null;
}

/** Check if an element can accept a "src" or "source" attribute per schema */
function getSrcAttributeName(schema: ParsedSchema | null, tagName: string): string | null {
  if (!schema) return null;
  const el = schema.elements[tagName];
  if (!el) return null;
  for (const attr of el.allowedAttributes) {
    const lower = attr.name.toLowerCase();
    if (lower === "src" || lower === "source") return attr.name;
  }
  return null;
}

const XmlTreeView: React.FC<XmlTreeViewProps> = ({
  root,
  selectedNodeId,
  schema,
  onSelectNode,
  onAddChild,
  onRemoveNode,
  onMoveNode,
  onCopyNode,
  onSetRoot,
  onReparentNode,
  onUpdateAttributes,
  onUpdateTagName,
}) => {
  const [newRootTag, setNewRootTag] = useState("");
  const [dragState, setDragState] = useState<DragState>({
    draggedNodeId: null,
    dropTargetId: null,
    dropPosition: null,
  });

  const handleCreateRoot = (tagName: string) => {
    if (!tagName.trim()) return;
    const node = createXmlNode(tagName.trim(), null);
    onSetRoot(node);
    setNewRootTag("");
  };

  const handleDragStart = useCallback((nodeId: string) => {
    setDragState({ draggedNodeId: nodeId, dropTargetId: null, dropPosition: null });
  }, []);

  const handleDragOver = useCallback((nodeId: string, position: "before" | "inside" | "after") => {
    setDragState((prev) => ({
      ...prev,
      dropTargetId: nodeId,
      dropPosition: position,
    }));
  }, []);

  const handleDragEnd = useCallback(() => {
    setDragState({ draggedNodeId: null, dropTargetId: null, dropPosition: null });
  }, []);

  const handleDrop = useCallback((targetNodeId: string, position: "before" | "inside" | "after") => {
    const { draggedNodeId } = dragState;
    if (!draggedNodeId || !onReparentNode || !root) return;
    if (draggedNodeId === targetNodeId) return;

    const targetNode = findNodeById(root, targetNodeId);
    if (!targetNode) return;

    if (position === "inside") {
      onReparentNode(draggedNodeId, targetNodeId);
    } else {
      const parentId = targetNode.parent;
      if (!parentId) {
        // Target is root — treat before/after as inserting as first/last child of root
        if (position === "before") {
          onReparentNode(draggedNodeId, targetNodeId, 0);
        } else {
          onReparentNode(draggedNodeId, targetNodeId);
        }
      } else {
        const parent = findNodeById(root, parentId);
        if (!parent) return;
        const targetIdx = parent.children.findIndex((c: XmlNode) => c.id === targetNodeId);
        const draggedIdx = parent.children.findIndex((c: XmlNode) => c.id === draggedNodeId);
        let insertIdx = position === "before" ? targetIdx : targetIdx + 1;
        // If dragged node is in the same parent and before the target, removing it shifts indices down
        if (draggedIdx !== -1 && draggedIdx < targetIdx) {
          insertIdx -= 1;
        }
        onReparentNode(draggedNodeId, parentId, insertIdx);
      }
    }
    handleDragEnd();
  }, [dragState, onReparentNode, root, handleDragEnd]);

  /** Handle file dropped from the OS onto a node */
  const handleFileDrop = useCallback((nodeId: string, files: FileList) => {
    if (!root || !onUpdateAttributes) return;
    const node = findNodeById(root, nodeId);
    if (!node) return;
    const srcAttr = getSrcAttributeName(schema, node.tagName);
    if (!srcAttr) return;
    const fileName = files[0]?.name;
    if (!fileName) return;
    onUpdateAttributes(nodeId, { ...node.attributes, [srcAttr]: fileName });
  }, [root, schema, onUpdateAttributes]);

  if (!root) {
    const rootOptions = schema?.rootElements ? [...schema.rootElements].sort((a, b) => a.localeCompare(b)) : [];
    return (
      <div className="flex flex-col items-center justify-center h-full min-h-[200px] p-8 text-center gap-4">
        <div className="text-foreground text-base font-medium">No XML document. Create a root element:</div>
        {rootOptions.length > 0 ? (
          <div className="flex flex-col gap-2">
            <select
              className="px-3 py-2 rounded border border-input bg-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
              value=""
              onChange={(e) => {
                if (e.target.value === "__other__") {
                  setNewRootTag("");
                  return;
                }
                handleCreateRoot(e.target.value);
              }}
            >
              <option value="" disabled>Select root element...</option>
              {rootOptions.map((name) => (
                <option key={name} value={name}>{name}</option>
              ))}
              <option value="__other__">Other...</option>
            </select>
          </div>
        ) : (
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Root element name..."
              value={newRootTag}
              onChange={(e) => setNewRootTag(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreateRoot(newRootTag)}
              className="px-3 py-2 rounded border border-input bg-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
            />
            <button
              onClick={() => handleCreateRoot(newRootTag)}
              disabled={!newRootTag.trim()}
              className="px-3 py-2 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-50 transition-colors"
            >
              Create
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="p-3 overflow-auto" style={{ minHeight: 100 }}>
      <TreeNode
        node={root}
        depth={0}
        selectedNodeId={selectedNodeId}
        schema={schema}
        onSelectNode={onSelectNode}
        onAddChild={onAddChild}
        onRemoveNode={onRemoveNode}
        onMoveNode={onMoveNode}
        onCopyNode={onCopyNode}
        onUpdateTagName={onUpdateTagName}
        isRoot
        isLastChild
        dragState={dragState}
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDragEnd={handleDragEnd}
        onDrop={handleDrop}
        onFileDrop={handleFileDrop}
      />
    </div>
  );
};

interface TreeNodeProps {
  node: XmlNode;
  depth: number;
  selectedNodeId: string | null;
  schema: ParsedSchema | null;
  parentAllowedChildren?: string[];
  onSelectNode: (id: string) => void;
  onAddChild: (parentId: string, tagName: string) => void;
  onRemoveNode: (id: string) => void;
  onMoveNode: (id: string, direction: "up" | "down") => void;
  onCopyNode: (id: string) => void;
  onUpdateTagName?: (nodeId: string, tagName: string) => void;
  isRoot?: boolean;
  isLastChild: boolean;
  dragState: DragState;
  onDragStart: (nodeId: string) => void;
  onDragOver: (nodeId: string, position: "before" | "inside" | "after") => void;
  onDragEnd: () => void;
  onDrop: (targetNodeId: string, position: "before" | "inside" | "after") => void;
  onFileDrop: (nodeId: string, files: FileList) => void;
}

const TreeNode: React.FC<TreeNodeProps> = ({
  node,
  depth,
  selectedNodeId,
  schema,
  onSelectNode,
  onAddChild,
  onRemoveNode,
  onMoveNode,
  onCopyNode,
  onUpdateTagName,
  isRoot,
  isLastChild,
  parentAllowedChildren,
  dragState,
  onDragStart,
  onDragOver,
  onDragEnd,
  onDrop,
  onFileDrop,
}) => {
  const [expanded, setExpanded] = useState(true);
  const [fileDropHover, setFileDropHover] = useState(false);
  const [renameOpen, setRenameOpen] = useState(false);
  const isSelected = selectedNodeId === node.id;
  const nodeRef = useRef<HTMLDivElement>(null);

  const allowedChildren = schema?.elements[node.tagName]?.allowedChildren || [];
  const canHaveChildren = !schema || allowedChildren.length > 0;
  const hasChildren = node.children.length > 0;

  // For rename: get allowed siblings from parent's schema
  const parentTagName = node.parent && schema ? (() => {
    // We don't have direct access to parent node here, so use schema rootElements for root children
    return null;
  })() : null;

  // Determine rename options: allowed children of the parent element in schema
  const getRenameOptions = (): string[] => {
    if (!schema) return [];
    // If root element, use rootElements
    if (isRoot) return [...schema.rootElements].sort((a, b) => a.localeCompare(b));
    // Otherwise we need to find what the parent allows — but we don't have parent node ref
    // We can iterate schema elements to find which ones list this node's tagName as child
    // Simpler: just show all known element names from schema
    // Actually, the parent's allowedChildren is what we need. Let's pass it down.
    return [];
  };

  // Check if this element can accept a file drop (has src/source attribute in schema)
  const srcAttrName = getSrcAttributeName(schema, node.tagName);
  const canAcceptFile = srcAttrName !== null;

  const isDragged = dragState.draggedNodeId === node.id;
  const isDropTarget = dragState.dropTargetId === node.id;

  const handleDragStartEvent = (e: React.DragEvent) => {
    if (isRoot) {
      e.preventDefault();
      return;
    }
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", node.id);
    onDragStart(node.id);
  };

  const isFileDrag = (e: React.DragEvent): boolean => {
    return e.dataTransfer.types.includes("Files") && !e.dataTransfer.types.includes("text/plain");
  };

  const handleDragOverEvent = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isFileDrag(e)) {
      if (canAcceptFile) {
        e.dataTransfer.dropEffect = "copy";
        setFileDropHover(true);
      } else {
        e.dataTransfer.dropEffect = "none";
        setFileDropHover(false);
      }
      return;
    }
    if (dragState.draggedNodeId === node.id) return;
    const rect = nodeRef.current?.getBoundingClientRect();
    if (!rect) return;
    const y = e.clientY - rect.top;
    const height = rect.height;
    if (y < height * 0.25) {
      onDragOver(node.id, "before");
    } else if (y > height * 0.75) {
      onDragOver(node.id, "after");
    } else {
      onDragOver(node.id, "inside");
    }
  };

  const handleDragLeaveEvent = () => {
    setFileDropHover(false);
  };

  const handleDropEvent = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isFileDrag(e) || (e.dataTransfer.files.length > 0 && !dragState.draggedNodeId)) {
      setFileDropHover(false);
      if (canAcceptFile && e.dataTransfer.files.length > 0) {
        onFileDrop(node.id, e.dataTransfer.files);
      }
      return;
    }
    if (dragState.dropPosition) {
      onDrop(node.id, dragState.dropPosition);
    }
  };

  const dropIndicatorClass = isDropTarget && !isDragged
    ? dragState.dropPosition === "inside"
      ? "ring-2 ring-primary/60"
      : ""
    : "";

  const fileDropClass = fileDropHover && canAcceptFile
    ? "ring-2 ring-accent bg-accent/10"
    : "";

  const dropLineTop = isDropTarget && dragState.dropPosition === "before" && !isDragged;
  const dropLineBottom = isDropTarget && dragState.dropPosition === "after" && !isDragged;

  return (
    <div className={isDragged ? "opacity-40" : ""}>
      <div
        ref={nodeRef}
        onDragOver={handleDragOverEvent}
        onDragLeave={handleDragLeaveEvent}
        onDrop={handleDropEvent}
      >
        {dropLineTop && (
          <div className="h-0.5 bg-primary rounded-full mx-2" style={{ marginLeft: depth * 20 }} />
        )}
        <div
          draggable={!isRoot}
          onDragStart={handleDragStartEvent}
          onDragEnd={onDragEnd}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg cursor-pointer transition-all text-sm ${
            isSelected
              ? "bg-tree-node-selected border-2 border-primary/40 shadow-sm"
              : "bg-tree-node border border-tree-node-border hover:bg-tree-node-hover hover:border-primary/20"
          } ${dropIndicatorClass} ${fileDropClass}`}
          style={{ marginLeft: depth * 20 }}
          onClick={() => onSelectNode(node.id)}
        >
          {!isRoot && (
            <GripVertical className="w-3.5 h-3.5 text-muted-foreground cursor-grab shrink-0" />
          )}

          {hasChildren ? (
            <button
              onClick={(e) => { e.stopPropagation(); setExpanded(!expanded); }}
              className="p-0.5 hover:bg-secondary rounded shrink-0"
            >
              {expanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
          ) : (
            <span className="w-4.5 shrink-0" />
          )}

          {/* Tag name — clickable to rename via popover (only if schema is loaded) */}
          <TagNameLabel
            node={node}
            schema={schema}
            onUpdateTagName={onUpdateTagName}
            isRoot={isRoot}
            parentAllowedChildren={parentAllowedChildren}
          />

          {/* Inline attribute preview */}
          <AttributePreview node={node} schema={schema} />

          {node.textContent && (
            <span className="text-xs text-muted-foreground truncate max-w-[80px] ml-1">
              "{node.textContent}"
            </span>
          )}

          {fileDropHover && canAcceptFile && (
            <span className="text-xs text-accent font-medium ml-1 shrink-0 flex items-center gap-0.5">
              <FileDown className="w-3 h-3" /> {srcAttrName}
            </span>
          )}

          {/* Action buttons */}
          <div className="ml-auto flex items-center gap-0.5 shrink-0">
            {canHaveChildren && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onAddChild(node.id, allowedChildren.length === 1 ? allowedChildren[0] : "element");
                  setExpanded(true);
                }}
                className="p-1 rounded hover:bg-accent/20 text-accent transition-colors"
                title="Add child element"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              onClick={(e) => { e.stopPropagation(); onCopyNode(node.id); }}
              className="p-1 rounded hover:bg-primary/15 text-primary transition-colors"
              title="Duplicate element"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onMoveNode(node.id, "up"); }}
              className="p-1 rounded hover:bg-secondary text-muted-foreground transition-colors"
              title="Move up"
            >
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onMoveNode(node.id, "down"); }}
              className="p-1 rounded hover:bg-secondary text-muted-foreground transition-colors"
              title="Move down"
            >
              <ArrowDown className="w-3.5 h-3.5" />
            </button>
            {!isRoot && (
              <button
                onClick={(e) => { e.stopPropagation(); onRemoveNode(node.id); }}
                className="p-1 rounded hover:bg-destructive/20 text-destructive transition-colors"
                title="Delete element"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
        {dropLineBottom && !hasChildren && (
          <>
            <div className="h-0.5 bg-primary rounded-full mx-2" style={{ marginLeft: depth * 20 }} />
            {isLastChild && <div className="h-8" />}
          </>
        )}
      </div>

      {/* Children */}
      {expanded && hasChildren && (
        <div className="tree-connector" style={{ marginLeft: depth * 20 + 12 }}>
          {node.children.map((child, idx) => (
            <TreeNode
              key={child.id}
              node={child}
              depth={depth + 1}
              selectedNodeId={selectedNodeId}
              schema={schema}
              onSelectNode={onSelectNode}
              onAddChild={onAddChild}
              onRemoveNode={onRemoveNode}
              onMoveNode={onMoveNode}
              onCopyNode={onCopyNode}
              onUpdateTagName={onUpdateTagName}
              parentAllowedChildren={allowedChildren}
              isLastChild={idx === node.children.length - 1}
              dragState={dragState}
              onDragStart={onDragStart}
              onDragOver={onDragOver}
              onDragEnd={onDragEnd}
              onDrop={onDrop}
              onFileDrop={onFileDrop}
            />
          ))}
          {/* Trailing + button after last child */}
          {canHaveChildren && (
            <button
              onClick={() => {
                onAddChild(node.id, allowedChildren.length === 1 ? allowedChildren[0] : "element");
              }}
              className="flex items-center gap-1 px-2 py-1 mt-1 rounded text-xs text-muted-foreground hover:text-accent hover:bg-accent/10 transition-colors"
              style={{ marginLeft: (depth + 1) * 20 }}
              title="Add element"
            >
              <Plus className="w-3 h-3" />
              <span>Add element</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};

/** Inline attribute preview: shows key=value pairs prioritized by id, class, then schema order */
const AttributePreview: React.FC<{ node: XmlNode; schema: ParsedSchema | null }> = ({ node, schema }) => {
  const attrs = node.attributes;
  const keys = Object.keys(attrs);
  if (keys.length === 0) return null;

  // Prioritize: id first, class second, then schema order, then remaining
  const schemaOrder = schema?.elements[node.tagName]?.allowedAttributes.map(a => a.name) || [];
  const sorted = [...keys].sort((a, b) => {
    const rank = (k: string) => {
      if (k === "id") return -2;
      if (k === "class") return -1;
      const idx = schemaOrder.indexOf(k);
      return idx >= 0 ? idx : 9999;
    };
    return rank(a) - rank(b);
  });

  return (
    <span className="flex-1 min-w-0 ml-1.5 truncate text-[0.7rem] text-muted-foreground/70 font-mono">
      {sorted.map((k, i) => (
        <React.Fragment key={k}>
          {i > 0 && <span className="mx-0.5">·</span>}
          <span>{k}=<span className="text-muted-foreground/50">"{attrs[k]}"</span></span>
        </React.Fragment>
      ))}
    </span>
  );
};

/** Clickable tag name that opens a rename popover when schema has options */
const TagNameLabel: React.FC<{
  node: XmlNode;
  schema: ParsedSchema | null;
  onUpdateTagName?: (nodeId: string, tagName: string) => void;
  isRoot?: boolean;
  parentAllowedChildren?: string[];
}> = ({ node, schema, onUpdateTagName, isRoot, parentAllowedChildren }) => {
  const [open, setOpen] = useState(false);

  const getOptions = (): string[] => {
    if (!schema) return [];
    if (isRoot) return [...schema.rootElements].sort((a, b) => a.localeCompare(b));
    if (parentAllowedChildren && parentAllowedChildren.length > 0) {
      return [...parentAllowedChildren].sort((a, b) => a.localeCompare(b));
    }
    return [];
  };

  const options = getOptions();
  const hasOptions = options.length > 0 && onUpdateTagName;

  if (!hasOptions) {
    return (
      <span className="font-mono font-semibold text-[0.9rem] text-primary truncate">
        &lt;{node.tagName}&gt;
      </span>
    );
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          onClick={(e) => { e.stopPropagation(); setOpen(true); }}
          className="font-mono font-semibold text-[0.9rem] text-primary truncate hover:underline hover:text-primary/80 transition-colors"
        >
          &lt;{node.tagName}&gt;
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-48 p-1 max-h-60 overflow-auto" align="start" sideOffset={4}>
        {options.map((name) => (
          <button
            key={name}
            onClick={(e) => {
              e.stopPropagation();
              onUpdateTagName!(node.id, name);
              setOpen(false);
            }}
            className={`w-full text-left px-3 py-1.5 text-sm font-mono rounded hover:bg-accent/20 transition-colors ${
              name === node.tagName ? "bg-primary/10 text-primary font-bold" : "text-foreground"
            }`}
          >
            {name}
          </button>
        ))}
      </PopoverContent>
    </Popover>
  );
};

export default XmlTreeView;
