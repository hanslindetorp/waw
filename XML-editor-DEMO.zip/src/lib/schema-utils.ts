import { ParsedSchema, SchemaElement, SchemaAttribute } from "./xml-types";

// Parse an XSD schema string into our internal schema format
export function parseXsdSchema(xsdString: string): ParsedSchema | null {
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(xsdString, "application/xml");
    const errorNode = doc.querySelector("parsererror");
    if (errorNode) return null;

    const schema: ParsedSchema = { rootElements: [], elements: {} };
    const root = doc.documentElement;

    // Build maps of global declarations
    const globalElements: Record<string, Element> = {};
    const namedTypes: Record<string, Element> = {};
    const namedGroups: Record<string, Element> = {};
    const namedAttrGroups: Record<string, Element> = {};

    for (const child of Array.from(root.children)) {
      const ln = child.localName;
      const name = child.getAttribute("name");
      if (!name) continue;
      if (ln === "element") globalElements[name] = child;
      else if (ln === "complexType") namedTypes[name] = child;
      else if (ln === "group") namedGroups[name] = child;
      else if (ln === "attributeGroup") namedAttrGroups[name] = child;
    }

    // Root elements = top-level element declarations
    for (const name of Object.keys(globalElements)) {
      schema.rootElements.push(name);
    }

    // Process all global elements
    for (const [name, el] of Object.entries(globalElements)) {
      processElement(name, el, schema, globalElements, namedTypes, namedGroups, namedAttrGroups);
    }

    console.log("Parsed schema:", JSON.stringify(schema, null, 2));
    return schema;
  } catch (e) {
    console.error("Schema parse error:", e);
    return null;
  }
}

function processElement(
  name: string,
  el: Element,
  schema: ParsedSchema,
  globalElements: Record<string, Element>,
  namedTypes: Record<string, Element>,
  namedGroups: Record<string, Element>,
  namedAttrGroups: Record<string, Element>
) {
  if (schema.elements[name]) return;

  const schemaEl: SchemaElement = {
    name,
    allowedChildren: [],
    allowedAttributes: [],
  };

  // Reserve the slot to prevent infinite recursion
  schema.elements[name] = schemaEl;

  // Resolve the complexType for this element
  const complexType = resolveComplexType(el, namedTypes);

  if (complexType) {
    collectChildElements(complexType, schemaEl, schema, globalElements, namedTypes, namedGroups, namedAttrGroups);
    collectAttributes(complexType, schemaEl, namedAttrGroups);
  }
}

function resolveComplexType(el: Element, namedTypes: Record<string, Element>): Element | null {
  const typeName = el.getAttribute("type");
  if (typeName) {
    const localType = typeName.includes(":") ? typeName.split(":").pop()! : typeName;
    if (namedTypes[localType]) return namedTypes[localType];
  }
  for (const child of Array.from(el.children)) {
    if (child.localName === "complexType") return child;
  }
  return null;
}

function stripPrefix(name: string): string {
  return name.includes(":") ? name.split(":").pop()! : name;
}

function collectChildElements(
  container: Element,
  schemaEl: SchemaElement,
  schema: ParsedSchema,
  globalElements: Record<string, Element>,
  namedTypes: Record<string, Element>,
  namedGroups: Record<string, Element>,
  namedAttrGroups: Record<string, Element>
) {
  for (const child of Array.from(container.children)) {
    const ln = child.localName;

    if (ln === "sequence" || ln === "choice" || ln === "all") {
      collectChildElements(child, schemaEl, schema, globalElements, namedTypes, namedGroups, namedAttrGroups);
    } else if (ln === "group") {
      const ref = child.getAttribute("ref");
      if (ref) {
        const localRef = stripPrefix(ref);
        const groupDef = namedGroups[localRef];
        if (groupDef) {
          // Recurse into the group definition's children
          collectChildElements(groupDef, schemaEl, schema, globalElements, namedTypes, namedGroups, namedAttrGroups);
        }
      } else {
        // Inline group (named group definition) — recurse into its children
        collectChildElements(child, schemaEl, schema, globalElements, namedTypes, namedGroups, namedAttrGroups);
      }
    } else if (ln === "element") {
      const ref = child.getAttribute("ref");
      const elName = child.getAttribute("name");

      if (ref) {
        const localRef = stripPrefix(ref);
        if (!schemaEl.allowedChildren.includes(localRef)) {
          schemaEl.allowedChildren.push(localRef);
        }
        if (globalElements[localRef]) {
          processElement(localRef, globalElements[localRef], schema, globalElements, namedTypes, namedGroups, namedAttrGroups);
        }
      } else if (elName) {
        if (!schemaEl.allowedChildren.includes(elName)) {
          schemaEl.allowedChildren.push(elName);
        }
        // Process inline element definition
        processElement(elName, child, schema, globalElements, namedTypes, namedGroups, namedAttrGroups);
      }
    } else if (ln === "complexContent" || ln === "simpleContent") {
      for (const sub of Array.from(child.children)) {
        if (sub.localName === "extension" || sub.localName === "restriction") {
          const base = sub.getAttribute("base");
          if (base) {
            const localBase = stripPrefix(base);
            if (namedTypes[localBase]) {
              collectChildElements(namedTypes[localBase], schemaEl, schema, globalElements, namedTypes, namedGroups, namedAttrGroups);
            }
          }
          collectChildElements(sub, schemaEl, schema, globalElements, namedTypes, namedGroups, namedAttrGroups);
        }
      }
    }
  }
}

function collectAttributes(
  complexType: Element,
  schemaEl: SchemaElement,
  namedAttrGroups: Record<string, Element>
) {
  walkForAttributes(complexType, schemaEl, namedAttrGroups);
}

function walkForAttributes(
  el: Element,
  schemaEl: SchemaElement,
  namedAttrGroups: Record<string, Element>
) {
  for (const child of Array.from(el.children)) {
    const ln = child.localName;
    if (ln === "attribute") {
      const attrName = child.getAttribute("name");
      if (attrName && !schemaEl.allowedAttributes.some(a => a.name === attrName)) {
        schemaEl.allowedAttributes.push(parseAttributeDecl(child));
      }
    } else if (ln === "attributeGroup") {
      const ref = child.getAttribute("ref");
      if (ref) {
        const localRef = stripPrefix(ref);
        const groupDef = namedAttrGroups[localRef];
        if (groupDef) {
          walkForAttributes(groupDef, schemaEl, namedAttrGroups);
        }
      } else {
        // Inline attributeGroup
        walkForAttributes(child, schemaEl, namedAttrGroups);
      }
    } else if (ln === "simpleContent" || ln === "complexContent" || ln === "extension" || ln === "restriction") {
      walkForAttributes(child, schemaEl, namedAttrGroups);
    }
  }
}

function parseAttributeDecl(attr: Element): SchemaAttribute {
  const name = attr.getAttribute("name") || "unknown";
  const type = attr.getAttribute("type") || "";
  const use = attr.getAttribute("use");
  const defaultVal = attr.getAttribute("default") || undefined;

  const schemaAttr: SchemaAttribute = {
    name,
    type: "string",
    required: use === "required",
    defaultValue: defaultVal,
  };

  if (type.includes("integer") || type.includes("int") || type.includes("decimal") || type.includes("float") || type.includes("double")) {
    schemaAttr.type = "number";
    schemaAttr.minValue = 0;
    schemaAttr.maxValue = 100;
  } else if (type.includes("boolean")) {
    schemaAttr.type = "boolean";
  }

  const enums = attr.querySelectorAll("simpleType > restriction > enumeration");
  if (enums.length > 0) {
    schemaAttr.type = "enum";
    schemaAttr.enumValues = Array.from(enums).map((e) => e.getAttribute("value") || "");
  }

  // Parse pattern restriction
  const patternEl = attr.querySelector("simpleType > restriction > pattern");
  if (patternEl) {
    const patternValue = patternEl.getAttribute("value");
    if (patternValue) {
      schemaAttr.pattern = patternValue;
    }
  }

  const minInclusive = attr.querySelector("simpleType > restriction > minInclusive");
  const maxInclusive = attr.querySelector("simpleType > restriction > maxInclusive");
  if (minInclusive) {
    schemaAttr.type = "number";
    schemaAttr.minValue = parseFloat(minInclusive.getAttribute("value") || "0");
  }
  if (maxInclusive) {
    schemaAttr.type = "number";
    schemaAttr.maxValue = parseFloat(maxInclusive.getAttribute("value") || "100");
  }

  return schemaAttr;
}

export function getDefaultSchema(): ParsedSchema {
  return {
    rootElements: [],
    elements: {},
  };
}
