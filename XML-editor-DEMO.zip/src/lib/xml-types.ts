// Types for the XML editor application

export interface XmlNode {
  id: string;
  tagName: string;
  attributes: Record<string, string>;
  children: XmlNode[];
  textContent: string;
  parent: string | null; // parent id
}

export interface SchemaElement {
  name: string;
  allowedChildren: string[];
  allowedAttributes: SchemaAttribute[];
  minOccurs?: number;
  maxOccurs?: number | "unbounded";
}

export interface SchemaAttribute {
  name: string;
  type: "string" | "number" | "boolean" | "enum";
  required: boolean;
  enumValues?: string[];
  minValue?: number;
  maxValue?: number;
  defaultValue?: string;
  pattern?: string; // XSD regex pattern for validation
}

export interface ParsedSchema {
  rootElements: string[];
  elements: Record<string, SchemaElement>;
}
