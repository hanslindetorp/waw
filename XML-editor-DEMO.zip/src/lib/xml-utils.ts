import { XmlNode, ParsedSchema, SchemaElement, SchemaAttribute } from "./xml-types";

let nodeIdCounter = 0;

export function generateNodeId(): string {
  return `node_${++nodeIdCounter}`;
}

export function resetNodeIdCounter() {
  nodeIdCounter = 0;
}

// Parse XML string into XmlNode tree
export function parseXmlString(xmlString: string): XmlNode | null {
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(xmlString, "application/xml");
    const errorNode = doc.querySelector("parsererror");
    if (errorNode) return null;
    if (!doc.documentElement) return null;
    resetNodeIdCounter();
    return domToXmlNode(doc.documentElement, null);
  } catch {
    return null;
  }
}

function domToXmlNode(element: Element, parentId: string | null): XmlNode {
  const id = generateNodeId();
  const attributes: Record<string, string> = {};
  for (const attr of Array.from(element.attributes)) {
    attributes[attr.name] = attr.value;
  }

  const children: XmlNode[] = [];
  let textContent = "";

  for (const child of Array.from(element.childNodes)) {
    if (child.nodeType === Node.ELEMENT_NODE) {
      children.push(domToXmlNode(child as Element, id));
    } else if (child.nodeType === Node.TEXT_NODE) {
      const text = child.textContent?.trim() || "";
      if (text) textContent += text;
    }
  }

  return { id, tagName: element.tagName, attributes, children, textContent, parent: parentId };
}

// Serialize XmlNode tree to XML string
export function serializeXmlNode(node: XmlNode, indent: number = 0): string {
  const spaces = "  ".repeat(indent);
  const attrs = Object.entries(node.attributes)
    .map(([k, v]) => ` ${k}="${escapeXml(v)}"`)
    .join("");

  if (node.children.length === 0 && !node.textContent) {
    return `${spaces}<${node.tagName}${attrs} />`;
  }

  let result = `${spaces}<${node.tagName}${attrs}>`;

  if (node.children.length > 0) {
    result += "\n";
    for (const child of node.children) {
      result += serializeXmlNode(child, indent + 1) + "\n";
    }
    if (node.textContent) {
      result += `${spaces}  ${escapeXml(node.textContent)}\n`;
    }
    result += `${spaces}</${node.tagName}>`;
  } else {
    result += escapeXml(node.textContent);
    result += `</${node.tagName}>`;
  }

  return result;
}

export function generateFullXml(root: XmlNode): string {
  return `<?xml version="1.0" encoding="UTF-8"?>\n${serializeXmlNode(root, 0)}`;
}

function escapeXml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

// Create a new empty XmlNode
export function createXmlNode(tagName: string, parentId: string | null): XmlNode {
  return {
    id: generateNodeId(),
    tagName,
    attributes: {},
    children: [],
    textContent: "",
    parent: parentId,
  };
}

// Find a node by ID in the tree
export function findNodeById(root: XmlNode, id: string): XmlNode | null {
  if (root.id === id) return root;
  for (const child of root.children) {
    const found = findNodeById(child, id);
    if (found) return found;
  }
  return null;
}

// Deep clone a node tree with new IDs
export function cloneNode(node: XmlNode, newParentId: string | null): XmlNode {
  const newId = generateNodeId();
  return {
    ...node,
    id: newId,
    parent: newParentId,
    children: node.children.map((c) => cloneNode(c, newId)),
  };
}

// Update parent references after tree modifications
export function updateParentRefs(node: XmlNode, parentId: string | null): XmlNode {
  return {
    ...node,
    parent: parentId,
    children: node.children.map((c) => updateParentRefs(c, node.id)),
  };
}

// Remove a node from the tree (returns new root or null if root was removed)
export function removeNode(root: XmlNode, nodeId: string): XmlNode | null {
  if (root.id === nodeId) return null;
  return {
    ...root,
    children: root.children
      .filter((c) => c.id !== nodeId)
      .map((c) => removeNode(c, nodeId)!)
      .filter(Boolean),
  };
}

// Insert a child node into a parent
export function insertChild(root: XmlNode, parentId: string, child: XmlNode, index?: number): XmlNode {
  if (root.id === parentId) {
    const newChildren = [...root.children];
    const insertIndex = index !== undefined ? index : newChildren.length;
    newChildren.splice(insertIndex, 0, { ...child, parent: parentId });
    return { ...root, children: newChildren };
  }
  return {
    ...root,
    children: root.children.map((c) => insertChild(c, parentId, child, index)),
  };
}

// Move a child up or down within its parent
export function moveChild(root: XmlNode, nodeId: string, direction: "up" | "down"): XmlNode {
  return {
    ...root,
    children: (() => {
      const idx = root.children.findIndex((c) => c.id === nodeId);
      if (idx === -1) {
        return root.children.map((c) => moveChild(c, nodeId, direction));
      }
      const newChildren = [...root.children];
      const swapIdx = direction === "up" ? idx - 1 : idx + 1;
      if (swapIdx < 0 || swapIdx >= newChildren.length) return newChildren;
      [newChildren[idx], newChildren[swapIdx]] = [newChildren[swapIdx], newChildren[idx]];
      return newChildren;
    })(),
  };
}

// Update a node's attributes
export function updateNodeAttributes(root: XmlNode, nodeId: string, attributes: Record<string, string>): XmlNode {
  if (root.id === nodeId) {
    return { ...root, attributes };
  }
  return {
    ...root,
    children: root.children.map((c) => updateNodeAttributes(c, nodeId, attributes)),
  };
}

// Update a node's tag name
export function updateNodeTagName(root: XmlNode, nodeId: string, tagName: string): XmlNode {
  if (root.id === nodeId) {
    return { ...root, tagName };
  }
  return {
    ...root,
    children: root.children.map((c) => updateNodeTagName(c, nodeId, tagName)),
  };
}

// Update a node's text content
export function updateNodeTextContent(root: XmlNode, nodeId: string, textContent: string): XmlNode {
  if (root.id === nodeId) {
    return { ...root, textContent };
  }
  return {
    ...root,
    children: root.children.map((c) => updateNodeTextContent(c, nodeId, textContent)),
  };
}

// Check if targetId is a descendant of node (or is node itself)
function isDescendantOf(node: XmlNode, targetId: string): boolean {
  if (node.id === targetId) return true;
  return node.children.some((c) => isDescendantOf(c, targetId));
}

// Reparent a node: remove from current location, insert as child of newParentId at given index
export function reparentNode(root: XmlNode, nodeId: string, newParentId: string, index?: number): XmlNode {
  const node = findNodeById(root, nodeId);
  if (!node) return root;
  // Can't reparent to self or own descendant
  if (isDescendantOf(node, newParentId)) return root;
  // Can't reparent root
  if (root.id === nodeId) return root;
  // Remove from old location
  let newRoot = removeNode(root, nodeId);
  if (!newRoot) return root;
  // Insert into new parent
  const reparented = { ...node, parent: newParentId };
  return insertChild(newRoot, newParentId, reparented, index);
}
