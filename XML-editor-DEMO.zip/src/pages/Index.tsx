import React, { useState, useCallback, useRef } from "react";
import { Code, TreePine } from "lucide-react";
import SchemaInput from "@/components/SchemaInput";
import XmlTreeView from "@/components/XmlTreeView";
import NodeInspector from "@/components/NodeInspector";
import XmlCodeEditor from "@/components/XmlCodeEditor";
import { XmlNode, ParsedSchema } from "@/lib/xml-types";
import {
  parseXmlString,
  generateFullXml,
  createXmlNode,
  findNodeById,
  cloneNode,
  removeNode,
  insertChild,
  moveChild,
  updateNodeAttributes,
  updateNodeTagName,
  updateNodeTextContent,
  reparentNode,
} from "@/lib/xml-utils";

const Index = () => {
  const [root, setRoot] = useState<XmlNode | null>(null);
  const [schema, setSchema] = useState<ParsedSchema | null>(null);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [codeValue, setCodeValue] = useState('<?xml version="1.0" encoding="UTF-8"?>');
  const updatingFromCode = useRef(false);
  const updatingFromTree = useRef(false);

  // Sync tree -> code
  const syncToCode = useCallback((newRoot: XmlNode | null) => {
    if (updatingFromCode.current) return;
    updatingFromTree.current = true;
    if (newRoot) {
      setCodeValue(generateFullXml(newRoot));
    } else {
      setCodeValue('<?xml version="1.0" encoding="UTF-8"?>');
    }
    updatingFromTree.current = false;
  }, []);

  // Sync code -> tree
  const handleCodeChange = useCallback((code: string) => {
    setCodeValue(code);
    if (updatingFromTree.current) return;
    updatingFromCode.current = true;
    const parsed = parseXmlString(code);
    if (parsed) {
      setRoot(parsed);
    }
    updatingFromCode.current = false;
  }, []);

  const handleSetRoot = useCallback((node: XmlNode) => {
    setRoot(node);
    setSelectedNodeId(node.id);
    syncToCode(node);
  }, [syncToCode]);

  const handleAddChild = useCallback((parentId: string, tagName: string) => {
    if (!root) return;
    const child = createXmlNode(tagName, parentId);
    const newRoot = insertChild(root, parentId, child);
    setRoot(newRoot);
    setSelectedNodeId(child.id);
    syncToCode(newRoot);
  }, [root, syncToCode]);

  const handleRemoveNode = useCallback((nodeId: string) => {
    if (!root) return;
    if (selectedNodeId === nodeId) setSelectedNodeId(null);
    const newRoot = removeNode(root, nodeId);
    setRoot(newRoot);
    syncToCode(newRoot);
  }, [root, selectedNodeId, syncToCode]);

  const handleMoveNode = useCallback((nodeId: string, direction: "up" | "down") => {
    if (!root) return;
    const newRoot = moveChild(root, nodeId, direction);
    setRoot(newRoot);
    syncToCode(newRoot);
  }, [root, syncToCode]);

  const handleCopyNode = useCallback((nodeId: string) => {
    if (!root) return;
    const node = findNodeById(root, nodeId);
    if (!node || !node.parent) return; // can't copy root in place
    const copy = cloneNode(node, node.parent);
    // Find the index of the original node in its parent and insert after it
    const parent = findNodeById(root, node.parent);
    if (!parent) return;
    const idx = parent.children.findIndex((c) => c.id === nodeId);
    const newRoot = insertChild(root, node.parent, copy, idx + 1);
    setRoot(newRoot);
    setSelectedNodeId(copy.id);
    syncToCode(newRoot);
  }, [root, syncToCode]);

  const handleReparentNode = useCallback((nodeId: string, newParentId: string, index?: number) => {
    if (!root) return;
    const newRoot = reparentNode(root, nodeId, newParentId, index);
    setRoot(newRoot);
    syncToCode(newRoot);
  }, [root, syncToCode]);
  const handleUpdateAttributes = useCallback((nodeId: string, attributes: Record<string, string>) => {
    if (!root) return;
    const newRoot = updateNodeAttributes(root, nodeId, attributes);
    setRoot(newRoot);
    syncToCode(newRoot);
  }, [root, syncToCode]);

  const handleUpdateTagName = useCallback((nodeId: string, tagName: string) => {
    if (!root) return;
    const newRoot = updateNodeTagName(root, nodeId, tagName);
    setRoot(newRoot);
    syncToCode(newRoot);
  }, [root, syncToCode]);

  const handleUpdateTextContent = useCallback((nodeId: string, text: string) => {
    if (!root) return;
    const newRoot = updateNodeTextContent(root, nodeId, text);
    setRoot(newRoot);
    syncToCode(newRoot);
  }, [root, syncToCode]);

  const selectedNode = root && selectedNodeId ? findNodeById(root, selectedNodeId) : null;

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Top bar */}
      <SchemaInput
        onSchemaLoaded={setSchema}
        hasSchema={schema !== null}
      />

      {/* Main split */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left panel: Tree + Inspector */}
        <div className="flex flex-col w-1/2 border-r border-border">
          <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-muted/30">
            <TreePine className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold uppercase tracking-wide text-foreground">
              XML Structure
            </span>
          </div>
          <div className="flex-1 min-h-0 overflow-auto">
            <XmlTreeView
              root={root}
              selectedNodeId={selectedNodeId}
              schema={schema}
              onSelectNode={setSelectedNodeId}
              onAddChild={handleAddChild}
              onRemoveNode={handleRemoveNode}
              onMoveNode={handleMoveNode}
              onCopyNode={handleCopyNode}
              onSetRoot={handleSetRoot}
              onReparentNode={handleReparentNode}
              onUpdateAttributes={handleUpdateAttributes}
              onUpdateTagName={handleUpdateTagName}
            />
          </div>
          <NodeInspector
            node={selectedNode}
            schema={schema}
            onUpdateAttributes={handleUpdateAttributes}
            onUpdateTagName={handleUpdateTagName}
            onUpdateTextContent={handleUpdateTextContent}
          />
        </div>

        {/* Right panel: Code editor */}
        <div className="flex flex-col w-1/2">
          <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-editor-gutter">
            <Code className="w-4 h-4 text-syntax-tag" />
            <span className="text-xs font-semibold uppercase tracking-wide text-syntax-text">
              XML Source
            </span>
          </div>
          <div className="flex-1 overflow-hidden">
            <XmlCodeEditor value={codeValue} onChange={handleCodeChange} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
